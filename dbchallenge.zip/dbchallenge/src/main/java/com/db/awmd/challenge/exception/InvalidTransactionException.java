package com.db.awmd.challenge.exception;

public class InvalidTransactionException extends RuntimeException {
	public InvalidTransactionException(String message) {
	    super(message);
	  }

}
