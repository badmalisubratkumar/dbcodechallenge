package com.db.awmd.challenge.dto;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ResponseFundTransfer{
	private String message;
	private Integer statusCode;

}